﻿; Выбор при каждой установке: создавать ярлык на рабочем столе или нет.
; Флажок показывается на последней странице установщика (рядом с "Запустить TwoDCraft").

; electron-builder собирает скрипт дважды (сначала деинсталлятор, потом установщик),
; а предупреждения компилятора NSIS у него считаются ошибками (warning 6010:
; функция объявлена, но не используется). Отключаем именно это предупреждение.
!pragma warning disable 6010

!macro customHeader
  !ifndef BUILD_UNINSTALLER
    Function TwoDCraftDesktopShortcut
      SetOutPath "$INSTDIR"
      CreateShortCut "$DESKTOP\TwoDCraft.lnk" "$INSTDIR\TwoDCraft.exe"
    FunctionEnd

    !define MUI_FINISHPAGE_SHOWREADME
    !define MUI_FINISHPAGE_SHOWREADME_TEXT "Создать ярлык на рабочем столе"
    !define MUI_FINISHPAGE_SHOWREADME_FUNCTION TwoDCraftDesktopShortcut
  !endif
!macroend

; при удалении программы убираем и ярлык на рабочем столе
!macro customUnInstall
  Delete "$DESKTOP\TwoDCraft.lnk"
!macroend
